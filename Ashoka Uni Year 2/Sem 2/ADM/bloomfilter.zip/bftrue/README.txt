Python version: 2.7
Make sure you have bitarray and murmurhash3 installed. (pip install bitarray; pip install mmh3)
Worked on by Divij and Jyotica

sed -i s/orange/apple/g q2.txt

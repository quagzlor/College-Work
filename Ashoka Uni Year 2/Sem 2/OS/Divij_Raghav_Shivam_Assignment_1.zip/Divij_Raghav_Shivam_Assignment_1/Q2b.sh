sed -i s/orange/apple/3 q2.txt

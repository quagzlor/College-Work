awk '(NR%3==1) {print}' 'q4_a.txt'

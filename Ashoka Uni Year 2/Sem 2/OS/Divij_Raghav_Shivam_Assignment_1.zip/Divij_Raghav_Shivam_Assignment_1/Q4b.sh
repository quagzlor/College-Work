awk '/ABC/ && NR%3==1 {print}' q4_b.txt

awk 'NR%3==1 && NF%2==0 {print}' PA1_test_data/q4_c.txt

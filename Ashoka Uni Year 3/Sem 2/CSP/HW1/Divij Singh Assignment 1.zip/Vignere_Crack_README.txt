Just run the script.
Copy paste the ciphertext, press enter.
See which text is actual english, and Bob's your uncle.
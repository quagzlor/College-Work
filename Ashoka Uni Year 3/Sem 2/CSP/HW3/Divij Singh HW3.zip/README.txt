Q8:
Just run the program.

Q9:
All the code is in the folder named 'RSA_Code'

keygenerator.py will automatically generate the primes, and output the public key and private key in text format, in decimal numbers.
public_key.txt will have the public key, then 'n' on the next line. private_key.txt will have the private key

Runtimes: (In Milliseconds)
1. 425 
2. 128
3. 635
4. 517
5. 439

Average: 428.8 Milliseconds
encrypt.py will take an integer from plaintext.txt, and take the public key and n from public_key.txt.
output will be an integer written in encrypted.txt

decrypt.py will take an integer from encrypted.txt, the private key from private_key.txt, and take the public key and n from public_key.txt.
output will be an integer written in decrypted.txt

Q10:
No